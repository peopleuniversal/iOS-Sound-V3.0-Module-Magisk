# Configuración del script del módulo Magisk

# ilustrar：
# 1. Coloque el archivo que desea reemplazar en la carpeta del sistema (elimine el archivo de marcador de posición)
# 2. Escribir información del módulo en module.prop
# 3. establecer en este archivo (customize.sh)
# 4. Si necesita ejecutar comandos en el momento del arranque, agréguelos a post-fs-data.sh o service.sh
# 5. Si necesita modificar la propiedad del sistema (build.prop), agréguela a system.prop

# Si necesita habilitar Magic Mount, configúrelo en verdadero; de lo contrario, configúrelo en falso
# La mayoría de los módulos requieren que esté habilitado
AUTOMOUNT=true

# Enumere todas las rutas que desea eliminar directamente en el sistema, una ruta por línea, solo carpetas, no archivos y solo carpetas en el sistema
# Este comando eliminará todos los archivos en las siguientes carpetas de ruta
# /system/modulostk/ es solo un ejemplo Si desea eliminar otras rutas, elimine ese ejemplo de línea
REPLACE="

"

# Este archivo (customize.sh) será generado (establecido como una variable de entorno) por el script de instalación después de util_functions.sh
# Si necesita operaciones personalizadas, defínalas aquí como funciones y llámelas en update-binary
# No agregue código directamente a update-binary ya que esto dificultará la migración de módulos a nuevas versiones de plantilla.
# Intente no realizar otras modificaciones en el archivo binario de actualización, intente realizar solo llamadas de función en él